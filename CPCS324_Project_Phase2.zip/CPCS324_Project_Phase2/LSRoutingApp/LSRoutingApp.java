package LSRoutingApp;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import GraphFramework.*;

public class LSRoutingApp{  /*  this function should be responsible for running the readGraphFromFile method for requirement 1
    and running the make graph function for requirement 2 to initialize the graph
   and invoking the Dijkstra algorithm 
   and displaying the returned result and the measured running time. 
*/
    public static void main(String[] args) throws FileNotFoundException {

        //Scanner to read input from user 
        Scanner input = new Scanner(System.in);
        int n = 0, m = 0, menuChoice = -1, choiceCase = -1;
        Graph graph;
        String choiceDigraph;
        boolean isDigraph = false;
        long finishTime, startTime;
        Dijkstra dijkstraAlg;

        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("\t\t     *** Shortest Path General Problem ***");
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("**** Please choose How you Want to Make the Graph ****");
        System.out.println("1- Create a Graph from a File ");
        System.out.println("2- Create a Random Graph ");
        System.out.print("> Enter your choice: ");
        menuChoice = input.nextInt();
        //If user enter Invalid menuChoice not 1 or 2 , loop until user enter correct input
        while (menuChoice != 1 && menuChoice != 2) {
            System.out.println("**** Invalid input! ****");
            System.out.print("> Enter your choice: ");
            menuChoice = input.nextInt();
        }
        //If user enter 1 or 2 complete the rest of the program 
        System.out.println("\n-----------------------------------------------------");

        //Switch to enter one of the options
        //Case 1 : Create a Graph from a File 
        //Case 2 : Create a Random Graph 
        switch (menuChoice) {          
            case 1:  // Create a Graph from a File 
                //Create object from class "File" --> to read graph from file  
                File fileInput = new File("graph.txt");
                graph = new Graph();
                isDigraph = true;//Let the graph be directed 
                graph.isDigraph = isDigraph;
                graph.readGraphFromFile(fileInput);  //call method "readGraphFromFile" to read graph from file 



                    System.out.println("\t      *** Weight Matrix ***");
                    System.out.println("-----------------------------------------------------");
                    graph.PrintGraphFile();
                    dijkstraAlg = new Dijkstra(graph);
                    System.out.println("\n-----------------------------------------------------");
                    System.out.println("         *** Length of the shortest paths ***");
                    System.out.println("-----------------------------------------------------");
                    startTime = System.currentTimeMillis();
                    dijkstraAlg.computeDijkstraAlg();
                    finishTime = System.currentTimeMillis();
                    // //Call printPath to print the the path from the source to all other vertices
                    dijkstraAlg.printPath();
                    System.out.println("\n *** Which represent the length from the chosen source to the rest of the vertices *** ");
                    System.out.println("\n-----------------------------------------------------");
                    System.out.println(" Run Time for Dijkstra Algorithm " + (finishTime - startTime) + " ms \n");
                
                break;
                
                
            //Case 2 : Create random graph
            case 2:
                //Ask user if he/she want to do the algorithm with direct graph
                System.out.print("Do you want the graph directed (y/n) ? ");
                choiceDigraph = input.next();
                //System.out.println("");
                //FOR WRONG INPUT
                if (!choiceDigraph.equalsIgnoreCase("y") && !choiceDigraph.equalsIgnoreCase("n")) {
                    System.out.println("\n**** Invalid input! ****");
                    System.out.print("> Enter your choice : ");
                    choiceDigraph = input.next();
                }
                //If the user answer was yes make directed graph
                if (choiceDigraph.equalsIgnoreCase("y")) {
                    isDigraph = true;
                }
                

               
                    //Ask user to choose one of this cases
                    //n-> means number of vertices in the graph
                    //m-> means number of edges in the graph
                    System.out.println("\n-----------------------------------------------------");
                    System.out.println("> Available cases (where n represents # of vertices and m represents # of edges ) : ");
                    System.out.println(" 1-  n=5000   - m=25,000");
                    System.out.println(" 2-  n=10,000 - m=50,000");
                    System.out.println(" 3-  n=15,000 - m=75,000");
                    System.out.println(" 4-  n=20,000 - m=100,000");
                    System.out.println(" 5-  n=25,000 - m=125,000");
                    System.out.print("> Enter a case to test: ");
                    choiceCase = input.nextInt();
                    //FOR WRONG INPUT
                    while (choiceCase < 1 || choiceCase > 6) {
                        System.out.println("**** Invalid input! ****");
                        System.out.print("> Enter a case to test: ");
                        choiceCase = input.nextInt();
                    }

                    System.out.println("\n-----------------------------------------------------");
                    //Switch to set n and m based on the user choice case
                    switch (choiceCase) {
                        case 1: {
                            n = 5000;
                            m = 25000;
                            break;
                        }

                        case 2: {
                            n = 10000;
                            m = 50000;
                            break;
                        }

                        case 3: {
                            n = 15000;
                            m = 75000;
                            break;
                        }

                        case 4: {
                            n = 20000;
                            m = 100000;
                            break;
                        }

                        case 5: {
                            n = 25000;
                            m = 125000;
                            break;
                        }
                    }
                    //Make random graph with specific parameter based on the above choice of the user
                    graph = new Graph(n, m, isDigraph);
                    graph.makeGraph(n, m);
                    //Create AllSourceSPAlg object to use dijkstra algorithm
                    dijkstraAlg = new Dijkstra(graph);//by default start with 0 
                    //Store the time before invoke the algorithm
                    startTime = System.currentTimeMillis();
                    dijkstraAlg.computeDijkstraAlg();
                    finishTime = System.currentTimeMillis();//Store the time after invoke the algorithm
                    //Print the running time
                    System.out.println("\n-----------------------------------------------------");
                    System.out.println(" Run time for Dijkstra algorithm " + (finishTime - startTime) + " ms \n");

                

                break;

        }
        //Print thanks message
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("\t\t     *** Thank you for Using the Program ***");
        System.out.println("--------------------------------------------------------------------------------");
    }//END MAIN METHOD
}