package LSRoutingApp;
import GraphFramework.*;

public class Path extends Edge{

    public Path(Vertex v, Vertex u, int w) {
        super(v, u, w);
    }
    /*The path length between two routers should be stored in the weight attribute is that is defined in the Edge class. 
note: path length is the edge weight, the route length is the one computed by Dijkstra algorithm. */

  
    
}
