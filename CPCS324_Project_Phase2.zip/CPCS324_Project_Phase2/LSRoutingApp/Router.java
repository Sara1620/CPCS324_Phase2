package LSRoutingApp;
import GraphFramework.*;

public class Router extends Vertex {
    
    String routerName;

    

    public String displayInfo(){
        return "RT. " + routerName;
    }
}
